<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915368798d4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceGateway\Data; class ClientSalePaymentRequest { public $Amount; public $OrderId; public $CallBackUrl; public $LoginAccount; public $AdditionalData; public function qiccuiwooiquycsg(array $yiosiwewiecqmkaa) { foreach ($yiosiwewiecqmkaa as $csgiecsagosuucqo => $eqgoocgaqwqcimie) { if (isset($this->{$csgiecsagosuucqo})) { $this->{$csgiecsagosuucqo} = $eqgoocgaqwqcimie; } } } }
